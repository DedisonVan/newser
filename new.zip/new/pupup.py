text = [('2023-02-17 01:30:00.907407', 722577116, 'https://naurok.com.ua/test/stvorennya-programnih-ob-ektiv-2028066/set')]

print(text[0][2])

